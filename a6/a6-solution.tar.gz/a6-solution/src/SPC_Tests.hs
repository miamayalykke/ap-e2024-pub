module SPC_Tests (tests) where

import Control.Concurrent (threadDelay)
import Control.Monad (forM, forM_, replicateM)
import Data.IORef
import SPC
import Test.Tasty (TestTree, localOption, mkTimeout, testGroup)
import Test.Tasty.HUnit (assertFailure, testCase, (@?=))

tests :: TestTree
tests =
  localOption (mkTimeout 3000000) $
    testGroup
      "SPC (core)"
      [ testCase "simple-job" $ do
          spc <- startSPC
          ref <- newIORef False
          j <- jobAdd spc $ Job (writeIORef ref True) 1
          r1 <- jobStatus spc j
          r1 @?= JobPending
          w <- either error pure =<< workerAdd spc "worker"
          r2 <- jobWait spc j
          r2 @?= Done
          workerStop w
          v <- readIORef ref
          v @?= True,
        --
        testCase "noworker" $ do
          spc <- startSPC
          ref <- newIORef False
          j <- jobAdd spc $ Job (writeIORef ref True) 1
          r1 <- jobStatus spc j
          r1 @?= JobPending
          jobCancel spc j
          r2 <- jobStatus spc j
          r2 @?= JobDone DoneCancelled
          v <- readIORef ref
          v @?= False,
        --
        testCase "timeout" $ do
          spc <- startSPC
          _w <- either error pure =<< workerAdd spc "worker"
          ref <- newIORef False
          j <- jobAdd spc $ Job (threadDelay 2000000 *> writeIORef ref True) 1
          r <- jobWait spc j
          r @?= DoneTimeout
          v <- readIORef ref
          v @?= False,
        --
        testCase "timeout-noworker" $ do
          spc <- startSPC
          ref <- newIORef False
          j <- jobAdd spc $ Job (writeIORef ref True) 1
          threadDelay 2000000
          _w <- either error pure =<< workerAdd spc "worker"
          r <- jobWait spc j
          r @?= Done
          v <- readIORef ref
          v @?= True,
        --
        testCase "job-crashing" $ do
          spc <- startSPC
          ref <- newIORef False
          j1 <- jobAdd spc $ Job (error "crash") 1
          _w <- either error pure =<< workerAdd spc "worker"
          r1 <- jobWait spc j1
          r1 @?= DoneCrashed
          j2 <- jobAdd spc $ Job (writeIORef ref True) 1
          r2 <- jobWait spc j2
          r2 @?= Done
          v <- readIORef ref
          v @?= True,
        --
        testCase "many-jobs" $ do
          spc <- startSPC
          let num_jobs = 10000 :: Int
              num_workers = 10 :: Int
          refs <- replicateM num_jobs (newIORef False)
          jobs <- forM refs $ \ref -> jobAdd spc $ Job (writeIORef ref True) 1
          workers <- forM [1 .. num_workers] $ \i ->
            either error pure =<< workerAdd spc ("worker" ++ show i)
          mapM_ (jobWait spc) jobs
          mapM_ workerStop workers
          forM_ refs $ \ref -> do
            v <- readIORef ref
            v @?= True,
        --
        testCase "stop-worker" $ do
          spc <- startSPC
          w <- either error pure =<< workerAdd spc "worker"
          j <- jobAdd spc $ Job (threadDelay 2000000 *> error "should not get here") 10
          threadDelay 1000 -- Hopefully the job runs now.
          r1 <- jobStatus spc j
          r1 @?= JobRunning
          workerStop w
          r2 <- jobWait spc j
          r2 @?= DoneCancelled,
        --
        testCase "duplicate-worker" $ do
          spc <- startSPC
          _w <- either error pure =<< workerAdd spc "worker"
          w <- workerAdd spc "worker"
          case w of
            Right _ -> assertFailure "allowed to add duplicate"
            Left _ -> pure ()
      ]
